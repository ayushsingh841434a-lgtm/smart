/**
 * face-api.js's FaceRecognitionNet produces a 128-dimensional descriptor per
 * face. The standard way to compare two descriptors is Euclidean distance:
 * roughly, distance < 0.6 means "very likely the same person" on face-api.js's
 * own benchmark (LFW). We default to a slightly stricter 0.5 and make it
 * configurable via FACE_MATCH_THRESHOLD, since real-world lighting/camera
 * quality in a classroom will differ from LFW's studio photos — tune this
 * against your own users before relying on it for grading/discipline
 * decisions.
 */
export const EMBEDDING_LENGTH = 128;

export const FACE_MATCH_THRESHOLD = Number(process.env.FACE_MATCH_THRESHOLD ?? 0.5);

export function euclideanDistance(a: number[], b: number[]): number {
  if (a.length !== b.length) {
    throw new Error(`Embedding length mismatch: ${a.length} vs ${b.length}`);
  }
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const d = a[i] - b[i];
    sum += d * d;
  }
  return Math.sqrt(sum);
}

export interface Candidate {
  studentId: string;
  vector: number[];
}

export interface MatchResult {
  studentId: string | null;
  distance: number | null;
  isMatch: boolean;
}

/** Finds the closest registered face to a live-captured descriptor. */
export function findBestMatch(liveVector: number[], candidates: Candidate[]): MatchResult {
  if (liveVector.length !== EMBEDDING_LENGTH) {
    throw new Error(`Live descriptor must be ${EMBEDDING_LENGTH}-dimensional`);
  }
  let best: { studentId: string; distance: number } | null = null;
  for (const c of candidates) {
    const d = euclideanDistance(liveVector, c.vector);
    if (!best || d < best.distance) best = { studentId: c.studentId, distance: d };
  }
  if (!best) return { studentId: null, distance: null, isMatch: false };
  return {
    studentId: best.studentId,
    distance: best.distance,
    isMatch: best.distance <= FACE_MATCH_THRESHOLD,
  };
}
