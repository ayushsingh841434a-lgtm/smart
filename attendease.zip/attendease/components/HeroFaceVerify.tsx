"use client";

import { useState } from "react";
import Link from "next/link";
import FaceCamera, { FaceCaptureResult } from "./FaceCamera";

export default function HeroFaceVerify() {
  const [active, setActive] = useState(false);
  const [captured, setCaptured] = useState<FaceCaptureResult | null>(null);

  return (
    <div className="scan-mock frame">
      <div className="screen">
        {!active && !captured && (
          <div className="scan-cta">
            <button className="btn btn-light btn-sm" onClick={() => setActive(true)}>
              Try live face detection
            </button>
          </div>
        )}
        {active && !captured && (
          <FaceCamera
            mode="verify"
            active={active}
            requiredStableFrames={6}
            onResult={(r) => setCaptured(r)}
          />
        )}
        {captured && (
          <div className="scan-cta" style={{ background: "rgba(15,157,99,.55)" }}>
            <div style={{ textAlign: "center", color: "#fff", padding: 16 }}>
              <p style={{ fontWeight: 700, marginBottom: 8 }}>✓ Face captured</p>
              <p style={{ fontSize: ".8rem", opacity: 0.9, marginBottom: 12 }}>
                Log in and open Mark Attendance to verify your identity against your registered
                face and record attendance.
              </p>
              <Link href="/login" className="btn btn-light btn-sm">
                Log in to verify
              </Link>
            </div>
          </div>
        )}
        {!active && !captured && (
          <div className="scan-frame">
            <i></i>
            <i></i>
            <i></i>
            <i></i>
          </div>
        )}
      </div>
    </div>
  );
}
