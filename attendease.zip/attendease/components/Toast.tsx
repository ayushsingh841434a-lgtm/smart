"use client";

import { createContext, useCallback, useContext, useState } from "react";

interface ToastItem {
  id: number;
  message: string;
  error?: boolean;
}

const ToastContext = createContext<{ toast: (msg: string, error?: boolean) => void }>({ toast: () => {} });
export const useToast = () => useContext(ToastContext);

export default function ToastHost({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);

  const toast = useCallback((message: string, error = false) => {
    const id = Date.now() + Math.random();
    setItems((cur) => [...cur, { id, message, error }]);
    setTimeout(() => setItems((cur) => cur.filter((i) => i.id !== id)), 3400);
  }, []);

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div id="toastHost">
        {items.map((i) => (
          <div key={i.id} className={`toast${i.error ? " err" : ""}`}>
            <span className="dot" />
            <span>{i.message}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
