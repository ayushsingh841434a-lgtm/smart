"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut } from "next-auth/react";

const studentNav = [
  { href: "/student/dashboard", label: "Dashboard", icon: "M3 12l9-9 9 9M5 10v10h14V10" },
  { href: "/student/attendance", label: "Mark Attendance", icon: "circle:12,8,4|M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" },
];
const teacherNav = [
  { href: "/teacher/dashboard", label: "Dashboard", icon: "M3 12l9-9 9 9M5 10v10h14V10" },
  { href: "/teacher/students", label: "Students", icon: "M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2|circle:9,7,4" },
  { href: "/teacher/register-face", label: "Register Face", icon: "circle:12,8,4|M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" },
  { href: "/teacher/reports", label: "Reports", icon: "M3 3v18h18|M7 15l4-5 3 3 5-7" },
];

function IconFromSpec({ spec }: { spec: string }) {
  return (
    <svg viewBox="0 0 24 24">
      {spec.split("|").map((part, i) =>
        part.startsWith("circle:") ? (
          <circle key={i} cx={part.split(":")[1].split(",")[0]} cy={part.split(":")[1].split(",")[1]} r={part.split(":")[1].split(",")[2]} />
        ) : (
          <path key={i} d={part} />
        )
      )}
    </svg>
  );
}

export default function Sidebar({ role, open, onClose }: { role: "STUDENT" | "TEACHER" | "ADMIN"; open: boolean; onClose: () => void }) {
  const pathname = usePathname();
  const items = role === "STUDENT" ? studentNav : teacherNav;

  return (
    <>
      <div className={`sidebar-scrim${open ? " show" : ""}`} onClick={onClose} />
      <aside id="sidebar" className={open ? "open" : ""}>
        <div className="brand">
          <span className="brand-mark">
            <svg viewBox="0 0 24 24">
              <path d="M9 3H5a2 2 0 0 0-2 2v4M15 3h4a2 2 0 0 1 2 2v4M9 21H5a2 2 0 0 1-2-2v-4M15 21h4a2 2 0 0 0 2-2v-4M8 12a4 4 0 1 0 8 0 4 4 0 0 0-8 0Z" />
            </svg>
          </span>
          AttendEase
        </div>
        <nav>
          {items.map((it) => (
            <Link key={it.href} href={it.href} className={`side-link${pathname === it.href ? " active" : ""}`} onClick={onClose}>
              <IconFromSpec spec={it.icon} />
              {it.label}
            </Link>
          ))}
        </nav>
        <div className="side-bottom">
          <a href="#" className="side-link" onClick={(e) => { e.preventDefault(); signOut({ callbackUrl: "/" }); }}>
            <svg viewBox="0 0 24 24">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" />
            </svg>
            Log out
          </a>
        </div>
      </aside>
    </>
  );
}
