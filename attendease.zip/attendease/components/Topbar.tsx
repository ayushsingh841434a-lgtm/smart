"use client";

import { useTheme } from "./Providers";

export default function Topbar({
  title,
  name,
  roleLabel,
  onMenuClick,
}: {
  title: string;
  name: string;
  roleLabel: string;
  onMenuClick: () => void;
}) {
  const { theme, toggle } = useTheme();
  const initials = name.split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase();

  return (
    <header id="topbar">
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <button className="icon-btn" onClick={onMenuClick} id="mobileMenuBtn">
          <svg className="ic" viewBox="0 0 24 24">
            <path d="M4 7h16M4 12h16M4 17h16" />
          </svg>
        </button>
        <h1>{title}</h1>
      </div>
      <div className="topbar-right">
        <button className="icon-btn" onClick={toggle} title="Toggle theme">
          {theme === "light" ? (
            <svg className="ic" viewBox="0 0 24 24">
              <path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8Z" />
            </svg>
          ) : (
            <svg className="ic" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="4" />
              <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
            </svg>
          )}
        </button>
        <div className="avatar-chip">
          <div className="ph">{initials}</div>
          <div className="who">
            <b>{name}</b>
            <span>{roleLabel}</span>
          </div>
        </div>
      </div>
    </header>
  );
}
