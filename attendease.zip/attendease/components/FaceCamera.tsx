"use client";

import { useEffect, useRef, useState, useCallback } from "react";

const MODEL_URL =
  process.env.NEXT_PUBLIC_FACE_MODELS_URL ||
  "https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js-models@master";

type Status =
  | "loading-models"
  | "idle"
  | "camera-denied"
  | "no-camera"
  | "camera-active"
  | "no-face"
  | "multiple-faces"
  | "too-far"
  | "too-close"
  | "poor-lighting"
  | "off-center"
  | "face-detected"
  | "stable"
  | "error";

export interface FaceCaptureResult {
  descriptor: number[];
  quality: number; // detector confidence, 0-1
}

interface FaceCameraProps {
  mode: "register" | "verify";
  active: boolean; // parent controls whether detection should be running
  requiredStableFrames?: number;
  onResult: (r: FaceCaptureResult) => void;
  /** register mode only: called once enough stable frames exist so the UI can enable a "Capture" button */
  onReadyToCapture?: (ready: boolean) => void;
  captureSignal?: number; // bump this number to trigger a capture in register mode
}

let modelsLoadingPromise: Promise<void> | null = null;

async function ensureModelsLoaded() {
  if (typeof window === "undefined") return;
  const faceapi = await import("face-api.js");
  if (!modelsLoadingPromise) {
    modelsLoadingPromise = Promise.all([
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
    ]).then(() => undefined);
  }
  await modelsLoadingPromise;
}

export const STATUS_LABEL: Record<Status, string> = {
  "loading-models": "Loading face detection models…",
  idle: "Face verification ready",
  "camera-denied": "Camera permission denied. Please allow camera access and retry.",
  "no-camera": "No camera found on this device.",
  "camera-active": "Camera active — position your face inside the frame",
  "no-face": "No face detected",
  "multiple-faces": "Multiple faces detected — only one person at a time",
  "too-far": "Move closer to the camera",
  "too-close": "Move back a little",
  "poor-lighting": "Poor lighting — try a brighter, more even light source",
  "off-center": "Center your face in the frame",
  "face-detected": "Face detected — verifying…",
  stable: "Good — hold still",
  error: "Something went wrong with the camera.",
};

export default function FaceCamera({
  mode,
  active,
  requiredStableFrames = 5,
  onResult,
  onReadyToCapture,
  captureSignal,
}: FaceCameraProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const stableCountRef = useRef(0);
  const lastDescriptorRef = useRef<number[] | null>(null);
  const lastQualityRef = useRef(0);
  const resolvedRef = useRef(false); // verify-mode: only fire onResult once per active session

  const [status, setStatus] = useState<Status>("idle");
  const [box, setBox] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [modelsReady, setModelsReady] = useState(false);

  // Load face-api.js models once.
  useEffect(() => {
    let cancelled = false;
    setStatus("loading-models");
    ensureModelsLoaded()
      .then(() => {
        if (!cancelled) {
          setModelsReady(true);
          setStatus("idle");
        }
      })
      .catch((e) => {
        console.error("Failed to load face detection models", e);
        if (!cancelled) setStatus("error");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  const stopCamera = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
    setBox(null);
    stableCountRef.current = 0;
    resolvedRef.current = false;
  }, []);

  const startCamera = useCallback(async () => {
    if (!modelsReady) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setStatus("camera-active");
      resolvedRef.current = false;
      loop();
    } catch (err: any) {
      if (err?.name === "NotAllowedError" || err?.name === "PermissionDeniedError") {
        setStatus("camera-denied");
      } else if (err?.name === "NotFoundError" || err?.name === "DevicesNotFoundError") {
        setStatus("no-camera");
      } else {
        console.error("getUserMedia error", err);
        setStatus("error");
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modelsReady]);

  const loop = useCallback(async () => {
    if (!videoRef.current || resolvedRef.current) return;
    const faceapi = await import("face-api.js");
    const video = videoRef.current;

    if (video.readyState === 4) {
      const detections = await faceapi
        .detectAllFaces(video, new faceapi.TinyFaceDetectorOptions({ inputSize: 320, scoreThreshold: 0.5 }))
        .withFaceLandmarks()
        .withFaceDescriptors();

      if (detections.length === 0) {
        setStatus("no-face");
        setBox(null);
        stableCountRef.current = 0;
      } else if (detections.length > 1) {
        setStatus("multiple-faces");
        setBox(null);
        stableCountRef.current = 0;
      } else {
        const d = detections[0];
        const vw = video.videoWidth || 640;
        const vh = video.videoHeight || 480;
        const { x, y, width, height } = d.detection.box;

        // mirror the box horizontally since the preview is CSS-mirrored
        const mirroredX = vw - x - width;
        setBox({
          x: (mirroredX / vw) * 100,
          y: (y / vh) * 100,
          w: (width / vw) * 100,
          h: (height / vh) * 100,
        });

        const widthRatio = width / vw;
        const centered = Math.abs(x + width / 2 - vw / 2) / vw < 0.28;
        const brightness = sampleBrightness(video);

        let frameStatus: Status = "face-detected";
        let ok = true;
        if (widthRatio < 0.16) {
          frameStatus = "too-far";
          ok = false;
        } else if (widthRatio > 0.75) {
          frameStatus = "too-close";
          ok = false;
        } else if (brightness < 55 || brightness > 240) {
          frameStatus = "poor-lighting";
          ok = false;
        } else if (!centered) {
          frameStatus = "off-center";
          ok = false;
        }

        if (ok) {
          stableCountRef.current += 1;
          lastDescriptorRef.current = Array.from(d.descriptor);
          lastQualityRef.current = d.detection.score;
          frameStatus = stableCountRef.current >= requiredStableFrames ? "stable" : "face-detected";
        } else {
          stableCountRef.current = 0;
        }
        setStatus(frameStatus);

        const isStable = stableCountRef.current >= requiredStableFrames;
        if (mode === "register") {
          onReadyToCapture?.(isStable);
        } else if (mode === "verify" && isStable && !resolvedRef.current) {
          resolvedRef.current = true;
          onResult({ descriptor: lastDescriptorRef.current!, quality: lastQualityRef.current });
        }
      }
    }
    rafRef.current = requestAnimationFrame(() => loop());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, requiredStableFrames, onResult, onReadyToCapture]);

  // start/stop based on `active`
  useEffect(() => {
    if (active && modelsReady) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => stopCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, modelsReady]);

  // manual capture trigger (register mode)
  useEffect(() => {
    if (captureSignal === undefined || captureSignal === 0) return;
    if (mode !== "register") return;
    if (lastDescriptorRef.current && stableCountRef.current >= requiredStableFrames) {
      onResult({ descriptor: lastDescriptorRef.current, quality: lastQualityRef.current });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [captureSignal]);

  return (
    <div className="cam-stage frame" id="camStage">
      <video ref={videoRef} autoPlay playsInline muted hidden={status === "loading-models" || !active} style={{ transform: "scaleX(-1)" }} />
      {(!active || status === "loading-models") && (
        <div className="cam-placeholder">
          <svg className="ic" viewBox="0 0 24 24" style={{ width: 52, height: 52, margin: "0 auto 14px", display: "block" }}>
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2Z" />
            <circle cx="12" cy="13" r="4" />
          </svg>
          <p>{status === "loading-models" ? "Loading face detection models…" : "Camera is off."}</p>
        </div>
      )}
      {active && status !== "loading-models" && (
        <div className="cam-status-pill">
          <span className="dotpulse" />
          <span>{STATUS_LABEL[status]}</span>
        </div>
      )}
      {box && (
        <div
          className="cam-face-box"
          style={{
            display: "block",
            left: `${box.x}%`,
            top: `${box.y}%`,
            width: `${box.w}%`,
            height: `${box.h}%`,
            borderColor: status === "stable" ? "var(--success)" : "var(--accent)",
          }}
        />
      )}
    </div>
  );
}

function sampleBrightness(video: HTMLVideoElement): number {
  const c = document.createElement("canvas");
  c.width = 32;
  c.height = 32;
  const ctx = c.getContext("2d");
  if (!ctx) return 128;
  ctx.drawImage(video, 0, 0, 32, 32);
  const { data } = ctx.getImageData(0, 0, 32, 32);
  let total = 0;
  for (let i = 0; i < data.length; i += 4) {
    total += 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
  }
  return total / (data.length / 4);
}
