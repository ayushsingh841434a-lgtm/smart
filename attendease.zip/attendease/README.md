# AttendEase — real face-recognition attendance system

This is a working Next.js app (not a static demo): real authentication,
a real Postgres database, and real in-browser face detection/matching via
`face-api.js`. It keeps the original AttendEase colors, typography, cards,
sidebar and navigation — `app/globals.css` is the same design system, just
wired to real data instead of demo JS.

## What's real vs. what you must configure

**Real, working out of the box (once you set env vars and push the schema):**
- Email/password auth (bcrypt-hashed, NextAuth) — no more "any email logs you in".
- Student and teacher/admin roles with route protection (`middleware.ts`).
- Camera-based face **detection** (single face / no face / multiple faces /
  too close / too far / poor lighting / off-center) — `components/FaceCamera.tsx`.
- Face **registration**: captures a 128-d descriptor client-side, stores only
  that vector in Postgres (`FaceEmbedding.vector`) — never the photo.
- Face **verification**: the live descriptor is sent to the server, compared
  by Euclidean distance against every registered student's stored vector,
  and the closest match under `FACE_MATCH_THRESHOLD` is accepted. No name is
  ever shown unless that comparison actually passed.
- Duplicate-attendance prevention via a DB unique constraint on
  `(studentId, sessionId)` — not app-level guesswork.
- Dashboards, subject-wise stats and reports computed from real rows, not
  hardcoded numbers. The old landing-page claims ("99.4% accuracy",
  "2.3s avg.", "18,400+ attendances", "Live on 40+ campuses", the fake
  "Priya Sharma" illustration) have been removed — there's a note instead
  explaining that accuracy/speed depend on your own cameras and lighting.

**You must configure before this is production-ready:**
- A Postgres database (`DATABASE_URL`).
- `NEXTAUTH_SECRET` / `NEXTAUTH_URL`.
- Decide where face model weights load from (`NEXT_PUBLIC_FACE_MODELS_URL`) —
  see `public/models/README.md`.
- Tune `FACE_MATCH_THRESHOLD` against your own enrolled students. 0.5 is a
  reasonable starting point for face-api.js's 128-d descriptors, not a
  measured number for your cameras.

## Why face-api.js, and its real limits

face-api.js runs entirely client-side (TensorFlow.js), which fits Vercel's
serverless model well — no GPU server to run, no per-image API cost, and no
photo ever leaves the device. The trade-off: it has **no liveness/anti-spoof
check**, so a printed photo or a video of someone's face can currently fool
it. For a graded or disciplinary use case, pair it with a secondary check
(teacher spot-checks, a QR/manual fallback for disputes) or swap the
matching step for a managed service with liveness detection — AWS
Rekognition, Azure Face, or Face++ all have Vercel-compatible HTTP APIs; the
integration point to replace is `lib/faceMatch.ts` + the two API routes that
call it (`app/api/face/register`, `app/api/attendance/mark`).

**Accuracy/speed have not been measured** on real users — don't publish a
percentage or a "2.3s" figure until you've actually tested it on your own
enrollment.

## Setup

```bash
npm install
cp .env.example .env       # fill in DATABASE_URL and NEXTAUTH_SECRET at minimum
npx prisma db push         # creates all tables in your Postgres database
npm run db:seed            # optional: creates one admin login + two subjects
npm run dev
```

Then open http://localhost:3000, sign up as a teacher (or log in with the
seeded admin), add a subject and a student, register that student's face
from **Students → Register face**, and mark attendance from the student's
own **Mark Attendance** page.

## Deploying to Vercel

1. Push this project to a GitHub repo and import it in Vercel.
2. Provision Postgres — Vercel Postgres, Neon, or Supabase all work. Copy
   its connection string.
3. In **Vercel → your project → Settings → Environment Variables**, add:
   | Variable | Value |
   |---|---|
   | `DATABASE_URL` | your Postgres connection string |
   | `NEXTAUTH_SECRET` | output of `openssl rand -base64 32` |
   | `NEXTAUTH_URL` | your production URL, e.g. `https://attendease.vercel.app` |
   | `FACE_MATCH_THRESHOLD` | `0.5` (tune later) |
   | `NEXT_PUBLIC_FACE_MODELS_URL` | the default CDN, or `/models` if you self-host (see `public/models/README.md`) |
4. Deploy. Vercel runs `npm run build`, which runs `prisma generate` then
   `next build` (see `package.json`).
5. After the first deploy, run `npx prisma db push` once against your
   production `DATABASE_URL` (locally, with that URL in your shell) to
   create the tables — or wire up `prisma migrate deploy` in CI if you
   prefer migrations over `db push`.

## Database schema

See `prisma/schema.prisma` — `User`, `Student`, `Teacher`, `FaceEmbedding`,
`Subject`, `ClassSession`, `Attendance`, with the enums `Role`,
`AttendanceStatus`, `AttendanceMethod`.

## Security notes

- Passwords are bcrypt-hashed (cost 12); nothing is ever stored in plain text.
- Face descriptors are only ever returned to the browser that captured them
  in the same request/response — the register and verify endpoints never
  echo other students' vectors back to any client.
- All mutating API routes check `getServerSession` and role before touching
  the database; `middleware.ts` also blocks `/student/*` and `/teacher/*`
  pages by role at the routing layer.
- Secrets live in environment variables only — nothing is hardcoded in
  client-shipped code (`NEXT_PUBLIC_*` vars are the only ones bundled into
  the browser, and none of them are secrets).
- Face registration requires an explicit consent checkbox before the camera
  step (`app/(app)/teacher/register-face/page.tsx`).

## What I could not verify from this environment

I don't have network access or a Postgres instance in this sandbox, so I
could not run `npm install`, `next build`, or an end-to-end register →
verify test here. Please run `npm install && npm run build` locally (or let
Vercel's build do it) before treating this as done — if there's a stray
type error or typo I'd normally catch by compiling, that's where it'll
show up, and I'm glad to fix anything that comes back.
