# Face detection model weights

This app uses `face-api.js` (TensorFlow.js) entirely in the browser — no
photos or embeddings are sent to a third-party recognition API. It needs
three small model weight files, loaded at runtime from
`NEXT_PUBLIC_FACE_MODELS_URL`:

- `tiny_face_detector_model-*`
- `face_landmark_68_model-*`
- `face_recognition_model-*`

## Quick start (default)

By default `.env.example` points `NEXT_PUBLIC_FACE_MODELS_URL` at a public
jsdelivr mirror of the official face-api.js model repo, so the app works
with zero setup.

## Recommended for production

Self-host the weights for speed and to avoid depending on a third-party
CDN's uptime:

1. Download the model files from
   https://github.com/justadudewhohacks/face-api.js-models
   (just the `tiny_face_detector`, `face_landmark_68`, and
   `face_recognition` files).
2. Place them in this folder (`/public/models`).
3. Set `NEXT_PUBLIC_FACE_MODELS_URL=/models` in your environment variables.
