/**
 * Bootstraps the minimum needed to start using the app for real:
 * one teacher/admin login, and a couple of subjects to attach class
 * sessions to. It intentionally does NOT create any student accounts,
 * face templates, or attendance records — those must come from real
 * signups and real verified attendance.
 *
 * Run: npm run db:seed
 */
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const email = process.env.SEED_ADMIN_EMAIL || "admin@yourcollege.edu";
  const password = process.env.SEED_ADMIN_PASSWORD || "ChangeMe123!";

  const existing = await prisma.user.findUnique({ where: { email } });
  if (!existing) {
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.user.create({
      data: {
        name: "Admin",
        email,
        passwordHash,
        role: "ADMIN",
        teacher: { create: { department: "Administration" } },
      },
    });
    console.log(`Created admin login: ${email} / ${password} — change this password after first login.`);
  } else {
    console.log("Admin already exists, skipping.");
  }

  const subjectSeeds = [
    { name: "Data Structures", code: "CS201" },
    { name: "Operating Systems", code: "CS301" },
  ];
  for (const s of subjectSeeds) {
    await prisma.subject.upsert({ where: { code: s.code }, update: {}, create: s });
  }
  console.log("Seeded subjects (edit/add more from the Teacher dashboard).");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
