import { Role } from "@prisma/client";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      name?: string | null;
      email?: string | null;
      role: Role;
      studentId: string | null;
      teacherId: string | null;
      className: string | null;
    };
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    uid: string;
    role: Role;
    studentId: string | null;
    teacherId: string | null;
    className: string | null;
  }
}
