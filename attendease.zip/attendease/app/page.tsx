import Link from "next/link";
import HeroFaceVerify from "@/components/HeroFaceVerify";

export default function LandingPage() {
  return (
    <div>
      <nav id="publicNav">
        <div className="bar">
          <div className="brand">
            <span className="brand-mark">
              <svg viewBox="0 0 24 24">
                <path d="M9 3H5a2 2 0 0 0-2 2v4M15 3h4a2 2 0 0 1 2 2v4M9 21H5a2 2 0 0 1-2-2v-4M15 21h4a2 2 0 0 0 2-2v-4M8 12a4 4 0 1 0 8 0 4 4 0 0 0-8 0Z" />
              </svg>
            </span>
            AttendEase
          </div>
          <div className="navlinks">
            <a href="#feat">Features</a>
            <a href="#how">How it works</a>
          </div>
          <div className="nav-actions">
            <Link className="btn btn-ghost btn-sm" href="/login">
              Log in
            </Link>
            <Link className="btn btn-primary btn-sm" href="/signup">
              Sign up
            </Link>
          </div>
        </div>
      </nav>

      <main>
        <section>
          <div className="hero">
            <div>
              <div className="eyebrow-tag">
                <span className="dot"></span> Face-verified attendance
              </div>
              <h1>
                Smart attendance.
                <br />
                <span className="grad">Smarter campus.</span>
              </h1>
              <p className="sub">
                Automate attendance with real, on-device face verification and a live attendance
                record — no roll calls, no proxy attendance, no spreadsheets.
              </p>
              <div className="hero-ctas">
                <Link className="btn btn-primary" href="/login">
                  Mark Attendance
                </Link>
                <Link className="btn btn-ghost" href="/signup">
                  Login / Sign Up
                </Link>
              </div>
              <p style={{ fontSize: ".8rem", color: "var(--text-faint)", maxWidth: "40ch" }}>
                Accuracy and speed figures aren&apos;t published here because they depend on your
                institution&apos;s cameras, lighting and enrolled students — measure them on your
                own data once you&apos;re live.
              </p>
            </div>
            <HeroFaceVerify />
          </div>
        </section>

        <section className="section" id="feat">
          <div className="section-head">
            <h2>Everything a department needs to run attendance</h2>
            <p>Built for lecture halls, labs and seminar rooms — one system for students, faculty and administrators.</p>
          </div>
          <div className="feature-grid">
            <FeatureCard title="Face Recognition" desc="An on-device face descriptor is matched against each student's registered template before anyone is marked present." />
            <FeatureCard title="Automatic Attendance" desc="A verified match instantly logs the student, subject, date and time — no manual entry." />
            <FeatureCard title="Real-Time Dashboard" desc="Teachers see who's present the moment they check in, updating live as students verify." />
            <FeatureCard title="Attendance Reports" desc="Subject-wise and date-range reports, exportable as CSV for your records." />
            <FeatureCard title="Secure & Reliable" desc="Only numeric face templates are stored, never raw photos, behind hashed credentials and role-based access." />
            <FeatureCard title="Student Management" desc="Teachers add students, register faces and edit records from one console." />
          </div>
        </section>

        <section className="section" id="how" style={{ background: "var(--bg-sunken)", borderTop: "1px solid var(--border)", borderBottom: "1px solid var(--border)" }}>
          <div className="section-head">
            <h2>From walking in to marked present</h2>
            <p>The same flow every session, whether it&apos;s a 40-seat lab or a 300-seat lecture hall.</p>
          </div>
          <div className="feature-grid">
            <FeatureCard title="1. Open Mark Attendance" desc="Student opens the camera screen for the current subject session." />
            <FeatureCard title="2. Face detected" desc="A bounding box locks onto the face once framing and lighting are good." />
            <FeatureCard title="3. Verified & logged" desc="The live descriptor is matched against registered templates and, if it passes the threshold, attendance is saved — duplicates are blocked automatically." />
          </div>
        </section>
      </main>

      <footer>
        <div className="footer-row">
          <span>© 2026 AttendEase.</span>
          <span>Facial data is used only for attendance verification and stored as encrypted templates, per your institution&apos;s privacy policy.</span>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ title, desc }: { title: string; desc: string }) {
  return (
    <div className="feature-card">
      <div className="feature-ic">
        <svg className="ic" viewBox="0 0 24 24">
          <circle cx="12" cy="8" r="4" />
          <path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" />
        </svg>
      </div>
      <h3>{title}</h3>
      <p>{desc}</p>
    </div>
  );
}
