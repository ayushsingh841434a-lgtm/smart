import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { EMBEDDING_LENGTH } from "@/lib/faceMatch";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const body = await req.json();
  let { studentId, vector, quality } = body as { studentId?: string; vector: number[]; quality?: number };

  // Students can only register their own face; teachers/admins must specify one.
  if (session.user.role === "STUDENT") {
    studentId = session.user.studentId ?? undefined;
  } else if (session.user.role === "TEACHER" || session.user.role === "ADMIN") {
    if (!studentId) {
      return NextResponse.json({ error: "studentId is required for teacher-led registration." }, { status: 400 });
    }
  } else {
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  }

  if (!studentId) {
    return NextResponse.json({ error: "No student profile associated with this account." }, { status: 400 });
  }
  if (!Array.isArray(vector) || vector.length !== EMBEDDING_LENGTH || vector.some((n) => typeof n !== "number" || Number.isNaN(n))) {
    return NextResponse.json(
      { error: `Invalid face descriptor — expected ${EMBEDDING_LENGTH} numbers from the detector.` },
      { status: 400 }
    );
  }

  const student = await prisma.student.findUnique({ where: { id: studentId } });
  if (!student) return NextResponse.json({ error: "Student not found." }, { status: 404 });

  const saved = await prisma.faceEmbedding.upsert({
    where: { studentId },
    create: { studentId, vector, quality: quality ?? null },
    update: { vector, quality: quality ?? null },
  });

  return NextResponse.json({ ok: true, studentId: saved.studentId, updatedAt: saved.updatedAt });
}
