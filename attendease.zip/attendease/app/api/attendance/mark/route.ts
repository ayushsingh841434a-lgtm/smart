import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { EMBEDDING_LENGTH, findBestMatch } from "@/lib/faceMatch";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  let body: { sessionId?: string; descriptor?: number[] };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }
  const { sessionId, descriptor } = body;

  if (!sessionId) return NextResponse.json({ error: "sessionId is required." }, { status: 400 });
  if (!Array.isArray(descriptor) || descriptor.length !== EMBEDDING_LENGTH) {
    return NextResponse.json({ error: `Invalid face descriptor — expected ${EMBEDDING_LENGTH} numbers.` }, { status: 400 });
  }

  const classSession = await prisma.classSession.findUnique({ where: { id: sessionId } });
  if (!classSession) return NextResponse.json({ error: "Class session not found." }, { status: 404 });

  const embeddings = await prisma.faceEmbedding.findMany({
    select: { studentId: true, vector: true },
  });
  if (embeddings.length === 0) {
    return NextResponse.json(
      { matched: false, reason: "no-registered-faces", message: "No students have registered a face yet." },
      { status: 200 }
    );
  }

  const match = findBestMatch(
    descriptor,
    embeddings.map((e) => ({ studentId: e.studentId, vector: e.vector }))
  );

  if (!match.isMatch || !match.studentId) {
    return NextResponse.json({
      matched: false,
      reason: "no-match",
      message: "Face not recognized. Please try again or contact your administrator.",
      distance: match.distance,
    });
  }

  const student = await prisma.student.findUnique({
    where: { id: match.studentId },
    include: { user: true },
  });
  if (!student) {
    return NextResponse.json({ matched: false, reason: "no-match", message: "Face not recognized." });
  }

  try {
    const record = await prisma.attendance.create({
      data: {
        studentId: student.id,
        sessionId: classSession.id,
        status: "PRESENT",
        method: "FACE",
        matchDistance: match.distance,
      },
    });
    return NextResponse.json({
      matched: true,
      duplicate: false,
      student: { name: student.user.name, studentCode: student.studentCode, className: student.className },
      attendance: { id: record.id, markedAt: record.markedAt, status: record.status },
      distance: match.distance,
    });
  } catch (err: any) {
    if (err?.code === "P2002") {
      // unique(studentId, sessionId) already exists
      const existing = await prisma.attendance.findUnique({
        where: { studentId_sessionId: { studentId: student.id, sessionId: classSession.id } },
      });
      return NextResponse.json({
        matched: true,
        duplicate: true,
        student: { name: student.user.name, studentCode: student.studentCode, className: student.className },
        attendance: existing ? { id: existing.id, markedAt: existing.markedAt, status: existing.status } : null,
        message: `${student.user.name} was already marked present for this session.`,
      });
    }
    console.error("attendance mark error", err);
    return NextResponse.json({ error: "Could not save attendance record — please try again." }, { status: 500 });
  }
}
