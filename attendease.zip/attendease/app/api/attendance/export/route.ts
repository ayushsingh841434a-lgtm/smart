import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user.role !== "TEACHER" && session.user.role !== "ADMIN")) {
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  }
  const { searchParams } = new URL(req.url);
  const subjectId = searchParams.get("subjectId") || undefined;

  const rows = await prisma.attendance.findMany({
    where: { session: { subjectId } },
    include: { student: { include: { user: true } }, session: { include: { subject: true } } },
    orderBy: { markedAt: "desc" },
    take: 5000,
  });

  const header = "Date,Student,Student ID,Class,Subject,Time,Status,Method\n";
  const body = rows
    .map((r) =>
      [
        r.session.date.toISOString().slice(0, 10),
        r.student.user.name,
        r.student.studentCode,
        r.session.className,
        r.session.subject.name,
        r.markedAt.toISOString(),
        r.status,
        r.method,
      ]
        .map((v) => `"${String(v).replace(/"/g, '""')}"`)
        .join(",")
    )
    .join("\n");

  return new NextResponse(header + body, {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="attendance-export.csv"`,
    },
  });
}
