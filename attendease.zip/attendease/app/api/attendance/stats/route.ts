import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const studentIdParam = searchParams.get("studentId") || undefined;
  const studentId = session.user.role === "STUDENT" ? session.user.studentId : studentIdParam;
  if (!studentId) return NextResponse.json({ error: "studentId is required." }, { status: 400 });

  const student = await prisma.student.findUnique({ where: { id: studentId } });
  if (!student) return NextResponse.json({ error: "Student not found." }, { status: 404 });

  if (session.user.role === "STUDENT" && session.user.studentId !== studentId) {
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  }

  const subjects = await prisma.subject.findMany({
    include: {
      sessions: {
        where: { className: student.className },
        include: { attendances: { where: { studentId } } },
      },
    },
  });

  const perSubject = subjects
    .filter((s) => s.sessions.length > 0)
    .map((s) => {
      const held = s.sessions.length;
      const attended = s.sessions.filter((sess) => sess.attendances.length > 0).length;
      return {
        subject: s.name,
        held,
        attended,
        pct: held === 0 ? 0 : Math.round((attended / held) * 100),
      };
    });

  const totalHeld = perSubject.reduce((a, b) => a + b.held, 0);
  const totalAttended = perSubject.reduce((a, b) => a + b.attended, 0);
  const overallPct = totalHeld === 0 ? 0 : Math.round((totalAttended / totalHeld) * 100);

  return NextResponse.json({ perSubject, totalHeld, totalAttended, overallPct });
}
