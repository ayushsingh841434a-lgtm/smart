import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const subjectId = searchParams.get("subjectId") || undefined;
  const studentIdParam = searchParams.get("studentId") || undefined;
  const from = searchParams.get("from");
  const to = searchParams.get("to");

  // Students can only ever see their own records.
  const studentId = session.user.role === "STUDENT" ? session.user.studentId ?? "__none__" : studentIdParam;

  const rows = await prisma.attendance.findMany({
    where: {
      studentId,
      session: {
        subjectId,
        date: from || to ? { gte: from ? new Date(from) : undefined, lte: to ? new Date(to) : undefined } : undefined,
      },
    },
    include: {
      student: { include: { user: { select: { name: true } } } },
      session: { include: { subject: true } },
    },
    orderBy: { markedAt: "desc" },
    take: 500,
  });

  return NextResponse.json(
    rows.map((r) => ({
      id: r.id,
      date: r.session.date,
      time: r.markedAt,
      studentName: r.student.user.name,
      studentCode: r.student.studentCode,
      subject: r.session.subject.name,
      className: r.session.className,
      status: r.status,
      method: r.method,
    }))
  );
}
