import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}
function endOfToday() {
  const d = new Date();
  d.setHours(23, 59, 59, 999);
  return d;
}

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const subjectId = searchParams.get("subjectId") || undefined;

  const sessions = await prisma.classSession.findMany({
    where: { subjectId },
    include: { subject: true, _count: { select: { attendances: true } } },
    orderBy: { date: "desc" },
    take: 50,
  });
  return NextResponse.json(sessions);
}

/** Get-or-create today's session for a subject, so the same "class" doesn't get duplicated every click. */
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });

  const { subjectId, className, startTime } = await req.json();
  if (!subjectId || !className) {
    return NextResponse.json({ error: "subjectId and className are required." }, { status: 400 });
  }

  const existing = await prisma.classSession.findFirst({
    where: { subjectId, className, date: { gte: startOfToday(), lte: endOfToday() } },
  });
  if (existing) return NextResponse.json(existing);

  const created = await prisma.classSession.create({
    data: { subjectId, className, startTime: startTime || new Date().toLocaleTimeString() },
  });
  return NextResponse.json(created, { status: 201 });
}
