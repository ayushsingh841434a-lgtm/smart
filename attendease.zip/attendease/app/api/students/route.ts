import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

function requireStaff(role?: string) {
  return role === "TEACHER" || role === "ADMIN";
}

export async function GET(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !requireStaff(session.user.role)) {
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  }
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") || "").trim();
  const className = searchParams.get("className") || undefined;

  const students = await prisma.student.findMany({
    where: {
      className: className || undefined,
      OR: q
        ? [
            { user: { name: { contains: q, mode: "insensitive" } } },
            { studentCode: { contains: q, mode: "insensitive" } },
          ]
        : undefined,
    },
    include: {
      user: { select: { name: true, email: true } },
      faceEmbedding: { select: { updatedAt: true } },
      _count: { select: { attendances: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(
    students.map((s) => ({
      id: s.id,
      name: s.user.name,
      email: s.user.email,
      studentCode: s.studentCode,
      className: s.className,
      faceRegistered: !!s.faceEmbedding,
      faceUpdatedAt: s.faceEmbedding?.updatedAt ?? null,
      attendanceCount: s._count.attendances,
    }))
  );
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !requireStaff(session.user.role)) {
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  }
  const body = await req.json();
  const { name, email, studentCode, className, password } = body as Record<string, string>;
  if (!name || !email || !studentCode || !className || !password) {
    return NextResponse.json({ error: "All fields are required." }, { status: 400 });
  }
  if (password.length < 8) {
    return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({
      data: {
        name,
        email: email.toLowerCase().trim(),
        passwordHash,
        role: "STUDENT",
        student: { create: { studentCode: studentCode.trim(), className: className.trim() } },
      },
      include: { student: true },
    });
    return NextResponse.json({ id: user.student!.id, name: user.name }, { status: 201 });
  } catch (err: any) {
    if (err?.code === "P2002") {
      return NextResponse.json({ error: "That email or student ID is already in use." }, { status: 409 });
    }
    console.error("create student error", err);
    return NextResponse.json({ error: "Could not create student." }, { status: 500 });
  }
}
