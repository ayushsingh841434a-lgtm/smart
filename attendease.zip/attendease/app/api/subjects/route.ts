import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Not authenticated." }, { status: 401 });
  const subjects = await prisma.subject.findMany({ orderBy: { name: "asc" } });
  return NextResponse.json(subjects);
}

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user.role !== "TEACHER" && session.user.role !== "ADMIN")) {
    return NextResponse.json({ error: "Not authorized." }, { status: 403 });
  }
  const { name, code } = await req.json();
  if (!name || !code) return NextResponse.json({ error: "Name and code are required." }, { status: 400 });

  try {
    const subject = await prisma.subject.create({
      data: { name, code, teacherId: session.user.teacherId },
    });
    return NextResponse.json(subject, { status: 201 });
  } catch (err: any) {
    if (err?.code === "P2002") return NextResponse.json({ error: "Subject code already exists." }, { status: 409 });
    console.error(err);
    return NextResponse.json({ error: "Could not create subject." }, { status: 500 });
  }
}
