import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { name, email, password, role, studentCode, className } = body as {
      name: string;
      email: string;
      password: string;
      role: "STUDENT" | "TEACHER";
      studentCode?: string;
      className?: string;
    };

    if (!name || !email || !password || !role) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: "Password must be at least 8 characters." }, { status: 400 });
    }
    if (role === "STUDENT" && !studentCode) {
      return NextResponse.json({ error: "Student ID is required." }, { status: 400 });
    }

    const existing = await prisma.user.findUnique({ where: { email: email.toLowerCase().trim() } });
    if (existing) {
      return NextResponse.json({ error: "An account with this email already exists." }, { status: 409 });
    }

    const passwordHash = await bcrypt.hash(password, 12);

    const user = await prisma.$transaction(async (tx) => {
      const created = await tx.user.create({
        data: {
          name,
          email: email.toLowerCase().trim(),
          passwordHash,
          role,
        },
      });

      if (role === "STUDENT") {
        await tx.student.create({
          data: {
            userId: created.id,
            studentCode: studentCode!.trim(),
            className: className?.trim() || "Unassigned",
          },
        });
      } else {
        await tx.teacher.create({ data: { userId: created.id } });
      }

      return created;
    });

    return NextResponse.json({ id: user.id, email: user.email }, { status: 201 });
  } catch (err: any) {
    if (err?.code === "P2002") {
      return NextResponse.json({ error: "That email or student ID is already registered." }, { status: 409 });
    }
    console.error("register error", err);
    return NextResponse.json({ error: "Could not create account." }, { status: 500 });
  }
}
