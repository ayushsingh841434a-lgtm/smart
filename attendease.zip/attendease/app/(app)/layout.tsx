"use client";

import { useSession } from "next-auth/react";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Sidebar from "@/components/Sidebar";
import Topbar from "@/components/Topbar";

const titles: Record<string, string> = {
  "/student/dashboard": "Student Dashboard",
  "/student/attendance": "Mark Attendance",
  "/teacher/dashboard": "Teacher Dashboard",
  "/teacher/students": "Students",
  "/teacher/register-face": "Register Student Face",
  "/teacher/reports": "Attendance Reports",
};

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (status === "unauthenticated") router.push("/login");
  }, [status, router]);

  if (status === "loading" || !session) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-muted)" }}>
        Loading…
      </div>
    );
  }

  const role = session.user.role;
  const roleLabel = role === "STUDENT" ? "Student" : role === "ADMIN" ? "Administrator" : "Faculty";

  return (
    <div id="appShell">
      <Sidebar role={role} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div id="appMain">
        <Topbar title={titles[pathname] || "Dashboard"} name={session.user.name || "User"} roleLabel={roleLabel} onMenuClick={() => setSidebarOpen(true)} />
        <div className="appview">{children}</div>
      </div>
    </div>
  );
}
