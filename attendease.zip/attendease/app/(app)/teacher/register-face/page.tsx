"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import FaceCamera, { FaceCaptureResult } from "@/components/FaceCamera";
import { useToast } from "@/components/Toast";

interface StudentRow {
  id: string;
  name: string;
  studentCode: string;
  className: string;
}

export default function RegisterFacePage() {
  return (
    <Suspense fallback={<p style={{ color: "var(--text-muted)" }}>Loading…</p>}>
      <RegisterFaceInner />
    </Suspense>
  );
}

function RegisterFaceInner() {
  const params = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();

  const [students, setStudents] = useState<StudentRow[]>([]);
  const [studentId, setStudentId] = useState(params.get("studentId") || "");
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [consent, setConsent] = useState(false);
  const [active, setActive] = useState(false);
  const [ready, setReady] = useState(false);
  const [captureSignal, setCaptureSignal] = useState(0);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [pendingCapture, setPendingCapture] = useState<FaceCaptureResult | null>(null);

  useEffect(() => {
    fetch("/api/students")
      .then((r) => r.json())
      .then((s) => setStudents(Array.isArray(s) ? s : []));
  }, []);

  const selected = students.find((s) => s.id === studentId);

  function goStep2() {
    if (!studentId) {
      setError("Select a student first.");
      return;
    }
    if (!consent) {
      setError("Please confirm the consent notice below before capturing biometric data.");
      return;
    }
    setError("");
    setStep(2);
  }

  async function handleCaptured(r: FaceCaptureResult) {
    setPendingCapture(r);
    setActive(false);
  }

  async function saveTemplate() {
    if (!pendingCapture) return;
    setSaving(true);
    setError("");
    try {
      const res = await fetch("/api/face/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ studentId, vector: pendingCapture.descriptor, quality: pendingCapture.quality }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not save face template.");
        setSaving(false);
        return;
      }
      setStep(3);
      toast(`Face registered for ${selected?.name}.`);
    } catch {
      setError("Network error — please try again.");
    } finally {
      setSaving(false);
    }
  }

  function retake() {
    setPendingCapture(null);
    setReady(false);
    setActive(true);
  }

  return (
    <div className="cam-wrap">
      <div className="regsteps">
        <div className={`rs ${step === 1 ? "active" : "done"}`}>
          <div className="circ">1</div>Select student
        </div>
        <div className={`rs ${step === 2 ? "active" : step > 2 ? "done" : ""}`}>
          <div className="circ">2</div>Capture face
        </div>
        <div className={`rs ${step === 3 ? "active" : ""}`}>
          <div className="circ">3</div>Confirm
        </div>
      </div>

      {error && <div className="form-error">{error}</div>}

      {step === 1 && (
        <div className="panel">
          <div className="field">
            <label>Student</label>
            <select className="filter" style={{ width: "100%" }} value={studentId} onChange={(e) => setStudentId(e.target.value)}>
              <option value="">Select a student…</option>
              {students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} — {s.studentCode} ({s.className})
                </option>
              ))}
            </select>
          </div>
          <label style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: ".83rem", color: "var(--text-muted)", margin: "16px 0" }}>
            <input type="checkbox" style={{ width: "auto", marginTop: 3 }} checked={consent} onChange={(e) => setConsent(e.target.checked)} />
            I confirm the student has consented to their facial data being captured and stored as an
            encrypted template, used only for attendance verification, per our institution&apos;s privacy
            policy.
          </label>
          <button className="btn btn-primary" onClick={goStep2}>
            Continue to face capture
          </button>
        </div>
      )}

      {step === 2 && (
        <>
          {!active && !pendingCapture && (
            <div className="cam-stage frame">
              <div className="cam-placeholder">
                <svg className="ic" viewBox="0 0 24 24" style={{ width: 52, height: 52, margin: "0 auto 14px", display: "block" }}>
                  <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2Z" />
                  <circle cx="12" cy="13" r="4" />
                </svg>
                <p>Open the camera to capture a reference face for {selected?.name}.</p>
                <button className="btn btn-primary btn-sm" style={{ marginTop: 14 }} onClick={() => setActive(true)}>
                  Open camera
                </button>
              </div>
            </div>
          )}
          {active && !pendingCapture && (
            <FaceCamera mode="register" active={active} requiredStableFrames={8} onReadyToCapture={setReady} onResult={handleCaptured} captureSignal={captureSignal} />
          )}
          {pendingCapture && (
            <div className="cam-stage frame" style={{ display: "flex", alignItems: "center", justifyContent: "center" }}>
              <div style={{ textAlign: "center", color: "#8890BE" }}>
                <svg className="ic" viewBox="0 0 24 24" style={{ width: 44, height: 44, margin: "0 auto 10px", display: "block", stroke: "var(--success)" }}>
                  <path d="M20 6 9 17l-5-5" />
                </svg>
                <p>Good frame captured — confirm below.</p>
              </div>
            </div>
          )}
          <div className="cam-controls">
            <button className="btn btn-ghost" onClick={() => { setActive(false); setPendingCapture(null); setStep(1); }}>
              Back
            </button>
            {active && !pendingCapture && (
              <button className="btn btn-primary" disabled={!ready} onClick={() => setCaptureSignal((n) => n + 1)}>
                Capture face
              </button>
            )}
            {pendingCapture && (
              <>
                <button className="btn btn-ghost" onClick={retake}>
                  Retake
                </button>
                <button className="btn btn-primary" onClick={saveTemplate} disabled={saving}>
                  {saving ? "Saving…" : "Save face template"}
                </button>
              </>
            )}
          </div>
        </>
      )}

      {step === 3 && (
        <>
          <div className="result-card show ok">
            <div className="ic">
              <svg className="ic" viewBox="0 0 24 24" style={{ stroke: "#fff" }}>
                <path d="M20 6 9 17l-5-5" />
              </svg>
            </div>
            <h3>Face registered successfully</h3>
            <p>
              {selected?.name} ({selected?.studentCode}) can now use face verification to mark attendance.
            </p>
          </div>
          <div className="cam-controls">
            <button
              className="btn btn-ghost"
              onClick={() => {
                setStep(2);
                setPendingCapture(null);
                setActive(true);
              }}
            >
              Retake
            </button>
            <button className="btn btn-primary" onClick={() => router.push("/teacher/students")}>
              Done
            </button>
          </div>
        </>
      )}

      <div className="privacy-note">
        <svg className="ic" viewBox="0 0 24 24">
          <rect x="3" y="11" width="18" height="10" rx="2" />
          <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </svg>
        <div>Only a numeric face template is stored — never the raw photo — encrypted at rest per your institution&apos;s privacy policy.</div>
      </div>
    </div>
  );
}
