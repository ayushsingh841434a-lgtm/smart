"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useToast } from "@/components/Toast";

interface StudentRow {
  id: string;
  name: string;
  studentCode: string;
  className: string;
  faceRegistered: boolean;
  attendanceCount: number;
}

export default function TeacherStudentsPage() {
  const { toast } = useToast();
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [q, setQ] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", studentCode: "", className: "", password: "" });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  function load() {
    fetch(`/api/students?q=${encodeURIComponent(q)}`)
      .then((r) => r.json())
      .then((s) => setStudents(Array.isArray(s) ? s : []));
  }

  useEffect(() => {
    const t = setTimeout(load, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q]);

  async function addStudent(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const res = await fetch("/api/students", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) {
      setError(data.error || "Could not add student.");
      return;
    }
    toast(`${form.name} added. Share their email + temporary password so they can log in.`);
    setForm({ name: "", email: "", studentCode: "", className: "", password: "" });
    setShowAdd(false);
    load();
  }

  return (
    <section>
      <div className="toolbar">
        <div className="search-box">
          <svg className="ic" viewBox="0 0 24 24" width="16" height="16">
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.3-4.3" />
          </svg>
          <input placeholder="Search students by name or ID…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <button className="btn btn-primary btn-sm" onClick={() => setShowAdd((v) => !v)}>
          {showAdd ? "Cancel" : "+ Add student"}
        </button>
      </div>

      {showAdd && (
        <div className="panel" style={{ marginBottom: 20 }}>
          {error && <div className="form-error">{error}</div>}
          <form onSubmit={addStudent} className="grid" style={{ gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <div className="field">
              <label>Full name</label>
              <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="field">
              <label>Email</label>
              <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="field">
              <label>Student ID</label>
              <input required value={form.studentCode} onChange={(e) => setForm({ ...form, studentCode: e.target.value })} />
            </div>
            <div className="field">
              <label>Class / Section</label>
              <input required value={form.className} onChange={(e) => setForm({ ...form, className: e.target.value })} />
            </div>
            <div className="field" style={{ gridColumn: "1 / -1" }}>
              <label>Temporary password (share with the student)</label>
              <input type="text" required minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
            <button className="btn btn-primary" style={{ gridColumn: "1 / -1" }} disabled={saving}>
              {saving ? "Adding…" : "Add student"}
            </button>
          </form>
        </div>
      )}

      {students.length === 0 ? (
        <div className="empty-state">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.5}>
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.3-4.3" />
          </svg>
          <p>No students yet — add your first student to get started.</p>
        </div>
      ) : (
        <div className="card-list">
          {students.map((s) => (
            <div className="student-card" key={s.id}>
              <div className="ph">{s.name.split(" ").map((w) => w[0]).join("").slice(0, 2)}</div>
              <h4>{s.name}</h4>
              <span>
                {s.studentCode} · {s.className}
              </span>
              <div style={{ marginTop: 8 }}>
                <span className={`badge ${s.faceRegistered ? "present" : "absent"}`}>
                  {s.faceRegistered ? "Face registered" : "No face on file"}
                </span>
              </div>
              <div className="actions">
                <Link href={`/teacher/register-face?studentId=${s.id}`} className="btn btn-light btn-sm">
                  {s.faceRegistered ? "Re-register face" : "Register face"}
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
