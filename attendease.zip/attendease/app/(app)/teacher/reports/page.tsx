"use client";

import { useEffect, useState } from "react";

interface Subject {
  id: string;
  name: string;
}
interface Row {
  id: string;
  date: string;
  time: string;
  studentName: string;
  studentCode: string;
  subject: string;
  className: string;
  status: string;
}

export default function ReportsPage() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [subjectId, setSubjectId] = useState("");
  const [q, setQ] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/subjects").then((r) => r.json()).then((s) => setSubjects(Array.isArray(s) ? s : []));
  }, []);

  useEffect(() => {
    setLoading(true);
    const url = subjectId ? `/api/attendance?subjectId=${subjectId}` : "/api/attendance";
    fetch(url)
      .then((r) => r.json())
      .then((d) => setRows(Array.isArray(d) ? d : []))
      .finally(() => setLoading(false));
  }, [subjectId]);

  const filtered = rows.filter(
    (r) => !q || r.studentName.toLowerCase().includes(q.toLowerCase()) || r.studentCode.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <section>
      <div className="toolbar">
        <div className="search-box">
          <svg className="ic" viewBox="0 0 24 24" width="16" height="16">
            <circle cx="11" cy="11" r="8" />
            <path d="m21 21-4.3-4.3" />
          </svg>
          <input placeholder="Search by student or ID…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <select className="filter" value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
          <option value="">All subjects</option>
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
        <a className="btn btn-primary btn-sm" href={`/api/attendance/export${subjectId ? `?subjectId=${subjectId}` : ""}`}>
          Export CSV
        </a>
      </div>

      <div className="panel">
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Student</th>
                <th>ID</th>
                <th>Subject</th>
                <th>Time</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {loading && (
                <tr>
                  <td colSpan={6} style={{ color: "var(--text-muted)" }}>
                    Loading…
                  </td>
                </tr>
              )}
              {!loading && filtered.length === 0 && (
                <tr>
                  <td colSpan={6} style={{ color: "var(--text-muted)" }}>
                    No attendance records match your filters.
                  </td>
                </tr>
              )}
              {filtered.map((r) => (
                <tr key={r.id}>
                  <td>{new Date(r.date).toLocaleDateString()}</td>
                  <td>{r.studentName}</td>
                  <td>{r.studentCode}</td>
                  <td>{r.subject}</td>
                  <td>{new Date(r.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</td>
                  <td>
                    <span className={`badge ${r.status}`}>{r.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
