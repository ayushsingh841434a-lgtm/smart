"use client";

import { useEffect, useState } from "react";

interface StudentRow {
  id: string;
  name: string;
  studentCode: string;
  faceRegistered: boolean;
}
interface AttendanceRow {
  id: string;
  studentName: string;
  studentCode: string;
  subject: string;
  time: string;
  status: string;
}

export default function TeacherDashboard() {
  const [students, setStudents] = useState<StudentRow[]>([]);
  const [today, setToday] = useState<AttendanceRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    Promise.all([
      fetch("/api/students").then((r) => r.json()),
      fetch(`/api/attendance?from=${start.toISOString()}`).then((r) => r.json()),
    ])
      .then(([s, a]) => {
        setStudents(Array.isArray(s) ? s : []);
        setToday(Array.isArray(a) ? a : []);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p style={{ color: "var(--text-muted)" }}>Loading dashboard…</p>;

  const presentIds = new Set(today.map((r) => r.studentCode));
  const presentCount = presentIds.size;
  const totalStudents = students.length;
  const absentCount = Math.max(totalStudents - presentCount, 0);
  const pct = totalStudents === 0 ? 0 : Math.round((presentCount / totalStudents) * 100);
  const facesRegistered = students.filter((s) => s.faceRegistered).length;

  return (
    <section>
      <div className="grid g-stats">
        <StatCard label="Total students" value={totalStudents} />
        <StatCard label="Present today" value={presentCount} />
        <StatCard label="Absent today" value={absentCount} />
        <StatCard label="Today's attendance" value={`${pct}%`} />
      </div>

      {facesRegistered < totalStudents && (
        <div className="alert-banner warning">
          <svg className="ic" viewBox="0 0 24 24">
            <path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
          </svg>
          <div>
            <b>{totalStudents - facesRegistered} student(s) haven&apos;t registered a face yet</b>
            <p>They won&apos;t be recognized by Mark Attendance until their face is registered.</p>
          </div>
        </div>
      )}

      <div className="panel">
        <div className="panel-head">
          <h3>Today&apos;s attendance activity</h3>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Student</th>
                <th>ID</th>
                <th>Subject</th>
                <th>Time</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {today.length === 0 && (
                <tr>
                  <td colSpan={5} style={{ color: "var(--text-muted)" }}>
                    No attendance marked yet today.
                  </td>
                </tr>
              )}
              {today.map((r) => (
                <tr key={r.id}>
                  <td>{r.studentName}</td>
                  <td>{r.studentCode}</td>
                  <td>{r.subject}</td>
                  <td>{new Date(r.time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</td>
                  <td>
                    <span className={`badge ${r.status}`}>{r.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="stat-card">
      <div className="val">{value}</div>
      <div className="lbl">{label}</div>
    </div>
  );
}
