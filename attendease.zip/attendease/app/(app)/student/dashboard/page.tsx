"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface Stats {
  perSubject: { subject: string; held: number; attended: number; pct: number }[];
  totalHeld: number;
  totalAttended: number;
  overallPct: number;
}
interface AttendanceRow {
  id: string;
  date: string;
  subject: string;
  status: string;
}

export default function StudentDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [history, setHistory] = useState<AttendanceRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch("/api/attendance/stats").then((r) => r.json()),
      fetch("/api/attendance").then((r) => r.json()),
    ])
      .then(([s, h]) => {
        setStats(s);
        setHistory(Array.isArray(h) ? h : []);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p style={{ color: "var(--text-muted)" }}>Loading your attendance…</p>;

  const overall = stats?.overallPct ?? 0;
  const hasAnyData = (stats?.totalHeld ?? 0) > 0;
  const circumference = 2 * Math.PI * 52;

  return (
    <section>
      {hasAnyData && overall < 75 && (
        <div className="alert-banner warning">
          <svg className="ic" viewBox="0 0 24 24">
            <path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" />
          </svg>
          <div>
            <b>Low attendance warning</b>
            <p>Your overall attendance is {overall}%, below the 75% requirement.</p>
          </div>
        </div>
      )}
      {!hasAnyData && (
        <div className="alert-banner">
          <svg className="ic" viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 8v4M12 16h.01" />
          </svg>
          <div>
            <b>No attendance recorded yet</b>
            <p>Mark your first attendance to see stats here.</p>
          </div>
        </div>
      )}

      <div className="two-col">
        <div className="panel">
          <div className="panel-head">
            <h3>Subject-wise attendance</h3>
          </div>
          {stats && stats.perSubject.length > 0 ? (
            stats.perSubject.map((s) => (
              <div className="subject-row" key={s.subject}>
                <span style={{ minWidth: 150, fontSize: ".87rem" }}>{s.subject}</span>
                <div className="bar">
                  <i style={{ width: `${s.pct}%`, background: s.pct < 75 ? "var(--danger)" : "var(--primary)" }} />
                </div>
                <b style={{ fontSize: ".87rem" }}>
                  {s.pct}% ({s.attended}/{s.held})
                </b>
              </div>
            ))
          ) : (
            <div className="empty-state">
              <p>No sessions held for your class yet.</p>
            </div>
          )}
        </div>
        <div className="panel">
          <div className="panel-head">
            <h3>Overall percentage</h3>
          </div>
          <div className="progress-ring-wrap">
            <div className="progress-ring">
              <svg viewBox="0 0 120 120">
                <circle className="bg" cx="60" cy="60" r="52" />
                <circle
                  className="fg"
                  cx="60"
                  cy="60"
                  r="52"
                  strokeDasharray={circumference}
                  strokeDashoffset={circumference * (1 - overall / 100)}
                />
              </svg>
              <div className="center">
                <b>{overall}%</b>
                <span>present</span>
              </div>
            </div>
            <div style={{ flex: 1 }}>
              <p style={{ fontSize: ".85rem", color: "var(--text-muted)", lineHeight: 1.6 }}>
                {hasAnyData
                  ? `You've attended ${stats?.totalAttended} of ${stats?.totalHeld} sessions held for your class.`
                  : "Attendance percentage will appear once sessions are held for your class."}
              </p>
              <Link href="/student/attendance" className="btn btn-primary btn-sm" style={{ marginTop: 14 }}>
                Mark today&apos;s attendance
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h3>Recent attendance history</h3>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Subject</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {history.length === 0 && (
                <tr>
                  <td colSpan={3} style={{ color: "var(--text-muted)" }}>
                    No records yet.
                  </td>
                </tr>
              )}
              {history.map((h) => (
                <tr key={h.id}>
                  <td>{new Date(h.date).toLocaleDateString()}</td>
                  <td>{h.subject}</td>
                  <td>
                    <span className={`badge ${h.status}`}>{h.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
