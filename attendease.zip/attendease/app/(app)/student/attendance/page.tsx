"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import FaceCamera, { FaceCaptureResult } from "@/components/FaceCamera";
import { useToast } from "@/components/Toast";

interface Subject {
  id: string;
  name: string;
  code: string;
}

type ResultState =
  | { kind: "none" }
  | { kind: "success"; name: string; studentCode: string; subject: string; time: string }
  | { kind: "duplicate"; name: string; message: string }
  | { kind: "fail"; message: string }
  | { kind: "error"; message: string };

export default function MarkAttendancePage() {
  const { data: session } = useSession();
  const { toast } = useToast();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [subjectId, setSubjectId] = useState("");
  const [active, setActive] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ResultState>({ kind: "none" });

  useEffect(() => {
    fetch("/api/subjects")
      .then((r) => r.json())
      .then((s: Subject[]) => {
        setSubjects(s);
        if (s.length > 0) setSubjectId(s[0].id);
      });
  }, []);

  async function handleCapture(r: FaceCaptureResult) {
    if (!subjectId) {
      toast("Select a subject first.", true);
      setActive(false);
      return;
    }
    setBusy(true);
    try {
      const subject = subjects.find((s) => s.id === subjectId);
      const className = session?.user?.className || undefined;

      const sessRes = await fetch("/api/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subjectId, className: className || "General", startTime: new Date().toLocaleTimeString() }),
      });
      if (!sessRes.ok) throw new Error("session-failed");
      const classSession = await sessRes.json();

      const markRes = await fetch("/api/attendance/mark", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: classSession.id, descriptor: r.descriptor }),
      });
      const data = await markRes.json();

      if (!markRes.ok) {
        setResult({ kind: "error", message: data.error || "Could not save attendance — please try again." });
      } else if (!data.matched) {
        setResult({ kind: "fail", message: data.message || "Face not recognized. Please try again or contact your administrator." });
      } else if (data.duplicate) {
        setResult({ kind: "duplicate", name: data.student.name, message: data.message });
      } else {
        setResult({
          kind: "success",
          name: data.student.name,
          studentCode: data.student.studentCode,
          subject: subject?.name || "",
          time: new Date(data.attendance.markedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        });
        toast(`Attendance recorded for ${data.student.name}`);
      }
    } catch (err) {
      setResult({ kind: "error", message: "Network or server error — please check your connection and try again." });
    } finally {
      setBusy(false);
      setActive(false);
    }
  }

  function retry() {
    setResult({ kind: "none" });
    setActive(true);
  }

  return (
    <div className="cam-wrap">
      <div className="session-select">
        <select className="filter" style={{ flex: 1 }} value={subjectId} onChange={(e) => setSubjectId(e.target.value)} disabled={active}>
          {subjects.length === 0 && <option>No subjects yet — ask your teacher to add one</option>}
          {subjects.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </select>
      </div>

      {result.kind === "none" && !active && (
        <div className="cam-stage frame">
          <div className="cam-placeholder">
            <svg className="ic" viewBox="0 0 24 24" style={{ width: 52, height: 52, margin: "0 auto 14px", display: "block" }}>
              <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2Z" />
              <circle cx="12" cy="13" r="4" />
            </svg>
            <p>Camera access is required to mark attendance.</p>
            <button className="btn btn-primary btn-sm" style={{ marginTop: 14 }} onClick={() => setActive(true)} disabled={!subjectId}>
              Enable camera
            </button>
          </div>
        </div>
      )}

      {active && (
        <FaceCamera mode="verify" active={active} requiredStableFrames={6} onResult={handleCapture} />
      )}

      {busy && <p style={{ textAlign: "center", marginTop: 14, color: "var(--text-muted)" }}>Verifying against registered faces…</p>}

      {result.kind !== "none" && (
        <div className={`result-card show ${result.kind === "success" ? "ok" : result.kind === "duplicate" ? "duplicate" : "fail"}`}>
          <div className="ic">
            {result.kind === "success" ? (
              <svg className="ic" viewBox="0 0 24 24" style={{ stroke: "#fff" }}>
                <path d="M20 6 9 17l-5-5" />
              </svg>
            ) : (
              <svg className="ic" viewBox="0 0 24 24" style={{ stroke: "#fff" }}>
                <path d="M18 6 6 18M6 6l12 12" />
              </svg>
            )}
          </div>
          {result.kind === "success" && (
            <>
              <h3>Attendance marked successfully ✓</h3>
              <p>Your identity was verified and attendance has been recorded.</p>
              <div className="result-meta">
                <div>
                  <b>{result.name}</b>Student
                </div>
                <div>
                  <b>{result.studentCode}</b>ID
                </div>
                <div>
                  <b>{result.subject}</b>Subject
                </div>
                <div>
                  <b>{result.time}</b>Time
                </div>
              </div>
            </>
          )}
          {result.kind === "duplicate" && (
            <>
              <h3>Already marked present</h3>
              <p>{result.message}</p>
            </>
          )}
          {(result.kind === "fail" || result.kind === "error") && (
            <>
              <h3>Face not recognized</h3>
              <p>{result.message}</p>
            </>
          )}
        </div>
      )}

      {result.kind !== "none" && (
        <div className="cam-controls">
          <button className="btn btn-primary" onClick={retry}>
            Try again
          </button>
        </div>
      )}

      <div className="privacy-note">
        <svg className="ic" viewBox="0 0 24 24">
          <rect x="3" y="11" width="18" height="10" rx="2" />
          <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </svg>
        <div>
          Your facial data is used only for attendance verification and is stored as an encrypted numeric
          template, never as a photo, per your institution&apos;s privacy policy.
        </div>
      </div>
    </div>
  );
}
