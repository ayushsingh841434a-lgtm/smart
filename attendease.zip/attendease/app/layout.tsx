import type { Metadata } from "next";
import "./globals.css";
import Providers from "@/components/Providers";
import ToastHost from "@/components/Toast";

export const metadata: Metadata = {
  title: "AttendEase — Smart Attendance Management",
  description: "Face-verified attendance for classrooms.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="light">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <Providers>
          <ToastHost>{children}</ToastHost>
        </Providers>
      </body>
    </html>
  );
}
