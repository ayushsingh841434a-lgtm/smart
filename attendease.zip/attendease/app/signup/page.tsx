"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function SignupPage() {
  const router = useRouter();
  const [role, setRole] = useState<"STUDENT" | "TEACHER">("STUDENT");
  const [form, setForm] = useState({ name: "", email: "", password: "", studentCode: "", className: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function set(k: string, v: string) {
    setForm((f) => ({ ...f, [k]: v }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, role }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Could not create account.");
        setLoading(false);
        return;
      }
      const signInRes = await signIn("credentials", { redirect: false, email: form.email, password: form.password });
      setLoading(false);
      if (signInRes?.error) {
        router.push("/login");
        return;
      }
      router.push(role === "STUDENT" ? "/student/dashboard" : "/teacher/dashboard");
    } catch {
      setError("Network error — please try again.");
      setLoading(false);
    }
  }

  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h2>Create your account</h2>
        <p className="lead">Set up access for your department in minutes.</p>
        <div className="role-toggle">
          <button type="button" className={role === "STUDENT" ? "active" : ""} onClick={() => setRole("STUDENT")}>
            Student
          </button>
          <button type="button" className={role === "TEACHER" ? "active" : ""} onClick={() => setRole("TEACHER")}>
            Teacher / Admin
          </button>
        </div>
        {error && <div className="form-error">{error}</div>}
        <form onSubmit={handleSubmit}>
          <div className="field">
            <label>Full name</label>
            <input required value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Aditi Verma" />
          </div>
          <div className="field">
            <label>Email address</label>
            <input type="email" required value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="you@college.edu" />
          </div>
          {role === "STUDENT" && (
            <>
              <div className="field">
                <label>Student ID</label>
                <input required value={form.studentCode} onChange={(e) => set("studentCode", e.target.value)} placeholder="CS21B045" />
              </div>
              <div className="field">
                <label>Class / Section</label>
                <input required value={form.className} onChange={(e) => set("className", e.target.value)} placeholder="CS-3B" />
              </div>
            </>
          )}
          <div className="field">
            <label>Password</label>
            <input type="password" required minLength={8} value={form.password} onChange={(e) => set("password", e.target.value)} placeholder="At least 8 characters" />
          </div>
          <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
            {loading ? "Creating account…" : "Create account"}
          </button>
        </form>
        <p className="auth-switch">
          Already have an account? <Link href="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
}
